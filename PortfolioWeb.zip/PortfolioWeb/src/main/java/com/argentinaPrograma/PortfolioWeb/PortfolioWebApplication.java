package com.argentinaPrograma.PortfolioWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortfolioWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortfolioWebApplication.class, args);
	}

}
